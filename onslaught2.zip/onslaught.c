// onslaught.c Author D. Bolton 24th January 2021

#include "hr_time.h"
#include <time.h>
#ifdef _WIN32
#include <SDL.h>   // All SDL App's need this 
#include <SDL_image.h>
#else
#include<linux/time.h>
#define __timespec_defined 1
#define __timeval_defined 1
#define __itimerspec_defined 1
#include <SDL2/SDL.h>   // All SDL App's need this 
#include <SDL2/SDL_image.h>
#endif
#include <stdio.h>
#include <stdlib.h>
#include "data.h"

#define QUITKEY SDLK_ESCAPE
#define WIDTH 1300
#define HEIGHT 760
#define NUMTEXTURES 10
#define LANDDISTANCE 7
#define LANDPOINTS 25
#define SEAPOINTS 15
#define MAPWIDTH 40
#define MAPHEIGHT 28
#define NUMLAYERS 8
#define MAXPOINTS 255

#define LAND 1
#define SEA 2
#define EMPTY 0

// enums
enum maptype {ltEmpty, ltLand, ltSea};
typedef enum maptype landtype;

// Macros
#define onMap(X,Y)(X>=0 && X <MAPWIDTH && Y>=0 && Y < MAPHEIGHT)
#define notAtEdge(X,Y) (X>=2 && X <MAPWIDTH-2 && Y>=2 && Y < MAPHEIGHT-2)

// SDL Objects
SDL_Texture* textures[NUMTEXTURES];
SDL_Window* screen = NULL;
SDL_Renderer *renderer;
SDL_Event event;
SDL_Rect source, destination, dst;

// structs
struct hex {
	int map;       // use for drawing
	int continent; 
	landtype island;  // ltempty, ltland or ltsea
};

// Used for counting the number of hexes on land and sea
struct continentsea {
	landtype island; 
	int count;
};

typedef struct hex hexloc;

// Variables
int errorCount = 0;
int keypressed;
int rectCount = 0;
stopWatch s;
hexloc map[MAPWIDTH][MAPHEIGHT];
const char* texturenames[NUMTEXTURES] = {"assets/seahex.png","assets/blue.png","assets/cyan.png","assets/green.png","assets/grey.png",
"assets/orange.png","assets/purple.png","assets/ltgreen.png","assets/yellow.png","assets/error.png"};
int genpointsx[MAXPOINTS];
int genpointsy[MAXPOINTS];
int pointindex,gennum,numContinents,totalLand;
struct continentsea allContinents[100];
int dirx[8] = { 0,1,1,1,0,-1,-1,-1 };  // 0 = N, 1 = NE, 2= E etc
int diry[8] = { -1,-1,0,1,1,1,0,-1 };


// returns a number between 1 and max 
int Random(int max) {
	return (rand() % max) + 1;
}

void LogError(char * msg,char * msg2) {
	printf("%s %s\n", msg, msg2);
	errorCount++;
}

// Loads a file into a texture
SDL_Texture* LoadTexture(const char* afile, SDL_Renderer* ren) {
	SDL_Texture* texture = IMG_LoadTexture(ren, afile);
	if (texture == 0) {
		LogError("Failed to load texture from ", (char *)afile);
		LogError("Error is ", (char *)SDL_GetError());
	}
	return texture;
}

// Loads all Textures from files by calling LoadTexture 
void LoadTextures() {
	for (int i = 0; i < NUMTEXTURES; i++) {
		textures[i] = LoadTexture(texturenames[i], renderer);
	}
}

// Sets Window caption according to state - eg in debug mode or showing fps 
void SetCaption(char * msg) {
		SDL_SetWindowTitle(screen, msg);
}

// Initialize all setup, set screen mode, load images etc 
void InitSetup() {
	srand((unsigned int)time(NULL));
	//srand(0);
	SDL_Init(SDL_INIT_EVERYTHING);
	SDL_CreateWindowAndRenderer(WIDTH, HEIGHT, SDL_WINDOW_SHOWN, &screen, &renderer);
	if (!screen) {
		LogError("InitSetup failed to create window","");
	}
	SetCaption("Onslaught");
	LoadTextures();
}

// Cleans up after game over 
void FinishOff() {
	SDL_DestroyRenderer(renderer);
	SDL_DestroyWindow(screen);
	//Quit SDL
	SDL_Quit();
	exit(0);
}

// read a character 
char getaChar() {
	int result = -1;

	while (SDL_PollEvent(&event)) {
		if (event.type == SDL_KEYDOWN)
		{
			result = event.key.keysym.sym;
			break;
		}
	}
	return result;
}

int isvalidhex(int y, int dir) {
	if ((y & 1) == 1) /* odd row */
	{
		if (dir == 5 || dir == 7)
			return 0;
		else
			return 1;
	}
	else
	{
		if (dir == 1 || dir == 3)
			return 0;
		else
			return 1;
	}
}

// isonmap, check if x and y are in the map, return 1 if so, 0 otherwise 
//int isonmap(int x, int y) {
//	if (x >= 0 && x < MAPWIDTH && y >= 0 && y < MAPHEIGHT)
//		return 1;
//	else return 0;
//}

// DrawHexagons - draws all map
void DrawHexagons() {
	SDL_Rect hex, target;
	int ix, iy, xo, yo, alt, mx, my;
	char buff[20];
	startTimer(&s);
	hex.h = 34;
	hex.w = 32;
	hex.x = 0;
	hex.y = 0;
	target.h = 34;
	target.w = 32;
	int numy = MAPHEIGHT;//(HEIGHT / 25) - 2;
	int numx = MAPWIDTH; //(WIDTH / 32) - 8;  was -1 
	int sizex = 32;

	alt = 1;
	for (iy = 0; iy < numy; iy++) {
		yo = iy * 25;
		my = iy;
		for (ix = 0; ix < numx; ix++) {
			xo = ix * 32;
			mx = ix;
			if (onMap(ix, iy)) {
				int m = map[ix][iy].map;
				int island = map[ix][iy].island;
				if (island == ltSea) m = 0;
				target.x = (xo + (alt * sizex / 2));
				target.y = yo;
				SDL_RenderCopy(renderer, textures[m], &hex, &target);
				//printf("c = %d x=%d y = %d\n",c,target.x,target.y);		
				// DrawHex(m, xo, yo, alt);
			}
		}
		alt = 1 - alt;  // toggle 1<->0 
	}
	stopTimer(&s);
	SDL_RenderPresent(renderer);
#ifdef WIN32
	snprintf(buff, sizeof(buff), "%10.6f", getElapsedTime(&s));
#else
	snprintf(buff, sizeof(buff), "%10.6f", diff(&s));
#endif
	SetCaption(buff);
}

// Finds a random land point with map = 0. If can't do it after 1000 tries gives up and returns 0
// If it succeeds, return 1
int FindRandomLand(int* x, int* y) {
	int tries = 1000;
	while (tries-- > 0) {
		*x = Random(MAPWIDTH) - 1;
		*y = Random(MAPHEIGHT) - 1;
		if (map[*x][*y].island == ltLand && map[*x][*y].map == -1)
			return 1;
	};
	return 0;
}

// Return 1 if distance is <= LANDDISTANCE
int NearLand(int xo, int yo) {
	for (int y = 0; y < MAPHEIGHT; y++) {
		for (int x = 0; x < MAPWIDTH; x++) {
			if (map[x][y].island == ltLand) {
				int distance = ((xo - x) * (xo - x)) + ((yo - y) * (yo - y));
				if (distance <= LANDDISTANCE) return 1;
			}
		}
	}
	return 0;
}

// add a point
void AddPoints( landtype island,int numpoints) {
	int i,x,y;
	int landCount = 0;
	for (i=0;i<numpoints;i++) {
		do {
			x=Random(MAPWIDTH-4)+2;
			y=Random(MAPHEIGHT-4)+2;
			if ((landCount >0) && (island == ltLand))    // For land points
				if (!NearLand(x, y)) // Pick land points 
					continue;        // nearish to other land points
		}
		while (map[x][y].island != ltEmpty);
		landCount++;
		map[x][y].island = island;
		genpointsx[pointindex]=x;
		genpointsy[pointindex++]=y;
	}
}

// AddaLayertoAllPoints - adds a layer round every land and sea point
void AddaLayertoAllPoints() {
	int i,x,y,xo,yo,cindex,pindex;
	pindex = Offset[gennum];
	for (i=0;i< NumLayerPoints[gennum];i++) {
		xo= circlepoints[pindex++];
		yo= circlepoints[pindex++];
		for (cindex=0;cindex < LANDPOINTS + SEAPOINTS;cindex++) {
			x= genpointsx[cindex];
			y= genpointsy[cindex];
			x+= xo;
			y+= yo;
			if (onMap(x,y) && notAtEdge(x,y)) {
				if (map[x][y].island == ltEmpty) {
				   map[x][y].island = (cindex < LANDPOINTS) ? ltLand : ltSea;
				}
			}
		}
	}
}

// FillinBlanks() 0- find all ltnull, change to lt sea 
void FillInBlanks() {
	int y,x;
	for (y=0;y<MAPHEIGHT;y++) {
		for (x=0;x<MAPWIDTH;x++) {
			if (map[x][y].island==ltEmpty)
			{
				map[x][y].island = ltSea;  // sea
				map[x][y].continent = -1;
				map[x][y].map = 0;
			}
		}
	}
}

/* Recursive sink or fill in */
void Sinkat(int x, int y, int cnum) {
	if (onMap(x, y)) {
		if (map[x][y].continent == cnum) {
			map[x][y].island = ltSea;
			map[x][y].continent = 0;
			map[x][y].map = 0; 

			Sinkat(x - 1, y, cnum);
			Sinkat(x + 1, y, cnum);
			Sinkat(x, y - 1, cnum);
			Sinkat(x, y + 1, cnum);
			Sinkat(x - 1, y - 1, cnum);
			Sinkat(x + 1, y - 1, cnum);
			Sinkat(x + 1, y + 1, cnum);
			Sinkat(x - 1, y + 1, cnum);
		}
	}
}

// sink all land with < mcount of 50
void SinkLand() {
	for (int i = 1; i < numContinents; i++) {
		if (allContinents[i].island== ltLand && allContinents[i].count < 50) {
			for (int y = 0; y < MAPHEIGHT; y++) {
				for (int x = 0; x < MAPWIDTH; x++) {
					if (map[x][y].island == ltLand && map[x][y].continent == i) {
						Sinkat(x, y, i);
						allContinents[i].count = 0; // Mark it as sunk
					}
				}
			}
		}
	}
}

// Recursive count function - counts size of land
void FillIn(int x, int y, int island) {
	if (onMap(x, y) && isvalidhex(x,y)) {
		if (island == map[x][y].island && map[x][y].continent == -1) {
			map[x][y].continent = numContinents;
			allContinents[numContinents].count++;
			FillIn(x - 1, y, island);
			FillIn(x + 1, y, island);
			FillIn(x, y - 1, island);
			FillIn(x, y + 1, island);
			FillIn(x - 1, y - 1, island);
			FillIn(x + 1, y - 1, island);
			FillIn(x + 1, y + 1, island);
			FillIn(x - 1, y + 1, island);
		}
	}
}

// CountContinents() - Work out the size of every contiguous ocean/land mass
void CountContinents() {
	int y,x;	
	numContinents=0;
	for (y=0;y<MAPHEIGHT;y++) {
		for (x=0;x<MAPWIDTH;x++) {
			if (map[x][y].continent== -1) {
				allContinents[numContinents].count=0;
				allContinents[numContinents].island = map[x][y].island; // either land or sea
				FillIn(x,y, map[x][y].island);				
				numContinents++;
			}
		}
	}
}

// Count how land square in 8 around this point
int CountLand(int x, int y) {
	int total = 0;
	for (int dir = 0; dir < 8; dir++) {
		int xdir = x + dirx[dir];
		int ydir = y + diry[dir];
		if (onMap(xdir, ydir) && isvalidhex(xdir,ydir) && map[xdir][ydir].island == ltLand) {
			total++;
		}
	}
	return total;
}

// Look at every land map location, count how many other lands are around it. if o or 1 then sink it
void TrimIsolatedLand() {
	for (int y = 0; y < MAPHEIGHT; y++) {
		for (int x = 0; x < MAPWIDTH; x++) {
			if (map[x][y].island == ltLand) {
				int landAround = CountLand(x, y);
				if (landAround < 2) {
					map[x][y].island = ltSea;
					map[x][y].continent = 0;
					map[x][y].map = 0;
				}
			}
		}
	}
}

// CheckLand returns 1 if #land continents between minland and maxland and land count between minlandcount and maxlandcount
int CheckLand() {
	int i,numland,count;
	count = MAPWIDTH * MAPHEIGHT;
	int minLandCount = (int)(count * 0.35);
	int maxLandCount = (int)(count * 0.6);
	numland=0;
	count=0;
	for (i=0;i<numContinents;i++) {
		if (allContinents[i].island== ltLand && allContinents[i].count>0) {	
			numland++;
			count += allContinents[i].count;
		}
	}
	totalLand = count;
	return (numland ==1 && count >= minLandCount && count <= maxLandCount )?1:0;
}

// Set Map to Empty
void ClearMap(){
	for (int y=0;y<MAPHEIGHT;y++){
		for (int x=0;x<MAPWIDTH;x++){
			map[x][y].map =  -1;
			map[x][y].continent = -1;
			map[x][y].island = ltEmpty;
		}
	}
}

// Debugging Aid Save map out
void SaveMap() {
	char* mapfilename = "Map.txt";
	char cmap[3] = { '.','+','~' };
	FILE * fh;
#ifdef WIN32
	int err = fopen_s(&fh, mapfilename, "wt");
	if (err) {
		printf("Problem writing to %s - map not saved", mapfilename);
		return;
	}
#else	
	fh = fopen("map.txt","wt");
#endif
	fprintf(fh,";MAP\n");
	for (int y=0;y<MAPHEIGHT;y++) {
		for (int x=0;x<MAPWIDTH;x++) {
			int c = map[x][y].island;		
			fputc(cmap[c],fh);
		}
		fprintf(fh, "    ");
		for (int x = 0; x < MAPWIDTH; x++) {
			int c = map[x][y].map; // 0-8 0=Sea-1..8 = player
			if (c == 0)
				fputc('~', fh);
			else
			    fputc(c + '0', fh);
		}
		fprintf(fh,"\n");
    }
	
	fprintf(fh,";Continents\n");
	for (int i=0;i< numContinents;i++) {
		fprintf(fh,"# %2d %c %d\n",i,cmap[allContinents[i].island], allContinents[i].count); 		
	}
		
	fclose(fh);    
}

// find an empty land hex somewhere near to this block
int GetNearByPoint(int x, int y, int* xp, int* yp) {
	//int xp2, yp2;
	for (int dir = 0; dir < 8; dir++) {
		*xp = dirx[dir] + x;
		*yp = diry[dir] + y;
		if (!onMap(*xp, *yp) || isvalidhex(x,y)) continue;
		if (map[*xp][*yp].island == ltLand && map[*xp][*yp].map == -1) {
			return 1;
		}
		// can't find a suitabl spot so look around last point
		/*if (!GetNearByPoint(*xp, *yp, &xp2, &yp2)) return 0;
		*xp = xp2;
		*yp = yp2;
		return 1;*/
	}
	return 0;
}

// Set a contiguous block of hexes to a player 
void AddBlockPerPlayer(int x, int y, int player, int* hexesperplayer) {
	for (int block = 0; block < 6; block++) {  // Add 6 bunches for each player
		int xp, yp;
		int blockSize = Random(5) + 1; // 2-6
		map[x][y].map = player;
		(*hexesperplayer)--;
		if (blockSize > *hexesperplayer) {
			blockSize = *hexesperplayer;
		}
		for (int i = 0; i < blockSize; i++) {
			if (*hexesperplayer > 0 && GetNearByPoint(x, y, &xp, &yp)) {
				map[xp][yp].map = player;
				(*hexesperplayer)--;
			}
		}

		if ((*hexesperplayer) == 0)
			return;
		// still got some more left so just find random spots all over the map
		while (*hexesperplayer > 0) {
			if (FindRandomLand(&xp, &yp)) {
				map[xp][yp].map = player;
				(*hexesperplayer)--;
			}
			else break; // can't add so bail out
		}
	}
}

// Allocate hexes to players, randomly in blocks
void SetPlayers(int numPlayers) {
	int x, y;
	int playerHexes = (int)(totalLand / numPlayers);
	for (int pl = 1; pl <= numPlayers; pl++) {
		int hexesPerPlayer = playerHexes;
		if (FindRandomLand(&x, &y)) {
			AddBlockPerPlayer(x, y, pl,&hexesPerPlayer);
		}

	}
}

//Look for odd hex that hasn't been set, set to random player
void FixErrors() { 
	for (int y = 0; y < MAPHEIGHT; y++) {
		for (int x = 0; x < MAPWIDTH; x++) {
			int m = map[x][y].map;
			if (m == -1) {
				map[x][y].map = Random(8);
			}
		}
	}
}

// BuildMap() 
void BuildMap() {	
	int completed=0;

	while (1) {	
		ClearMap();
		pointindex=0;
		AddPoints(ltLand,LANDPOINTS);		
		AddPoints(ltSea,SEAPOINTS);
		for (gennum=0;gennum < NUMLAYERS;gennum++) {
			AddaLayertoAllPoints();	
		}			
		FillInBlanks();
		TrimIsolatedLand();
		CountContinents();
		SinkLand();
		FixErrors();
		completed=CheckLand();
		if (completed)
		{
			SetPlayers(8);
			break;
		}
	}
	SaveMap();
}

// main game loop. Handles demo mode, high score and game play 
void GameLoop() {
	int gameRunning = 1;
	startTimer(&s);
	while (gameRunning)
	{
		DrawHexagons();
		while (SDL_PollEvent(&event)) {
			switch (event.type) {
				case SDL_KEYDOWN:
					keypressed = event.key.keysym.sym;
					if (keypressed == QUITKEY)
					{
						gameRunning = 0;
						break;
					}
					if (keypressed == SDLK_n) // new map
					{
						BuildMap();
						break;
					}
				case SDL_QUIT:  // if mouse click to close window 
				{
					gameRunning = 0;
					break;
				}
				case SDL_KEYUP: {
					break;
				}
			}  // switch 

		}  // while SDL_PollEvent 
	}
}

// main routine
int main(int argc,char * args[])
{
	InitSetup();
	BuildMap();
	GameLoop();
	FinishOff();
    return 0;
}
