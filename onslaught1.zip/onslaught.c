// onslaught.c Author D. Bolton 16th January 2021
#include "hr_time.h"
#include <time.h>
#include<linux/time.h>
#define __timespec_defined 1
#define __timeval_defined 1
#define __itimerspec_defined 1
#include <SDL2/SDL.h>   // All SDL App's need this 
#include <SDL2/SDL_image.h>
#include <stdio.h>
#include <stdlib.h>

#define QUITKEY SDLK_ESCAPE
#define WIDTH 1024
#define HEIGHT 768
#define NUMTEXTURES 9
#define MAPWIDTH 31
#define MAPHEIGHT 28

SDL_Texture* textures[NUMTEXTURES];
SDL_Window* screen = NULL;
SDL_Renderer *renderer;
SDL_Event event;
SDL_Rect source, destination, dst;

// Variables
int errorCount = 0;
int keypressed;
int rectCount = 0;
stopWatch s;
char map[MAPWIDTH][MAPHEIGHT];
const char* texturenames[NUMTEXTURES] = { "assets/blue.png","assets/cyan.png","assets/green.png","assets/grey.png",
"assets/orange.png","assets/purple.png","assets/salmon.png","assets/seahex.png","assets/yellow.png"};

// returns a number between 1 and max 
int Random(int max) {
	return (rand() % max) + 1;
}

void LogError(char * msg,char * msg2) {
	printf("%s %s\n", msg, msg2);
	errorCount++;
}

// Loads a file into a texture
SDL_Texture* LoadTexture(const char* afile, SDL_Renderer* ren) {
	SDL_Texture* texture = IMG_LoadTexture(ren, afile);
	if (texture == 0) {
		LogError("Failed to load texture from ", (char *)afile);
		LogError("Error is ", (char *)SDL_GetError());
	}
	return texture;
}

// Loads all Textures from files by calling LoadTexture 
void LoadTextures() {
	for (int i = 0; i < NUMTEXTURES; i++) {
		textures[i] = LoadTexture(texturenames[i], renderer);
	}
}

// Sets Window caption according to state - eg in debug mode or showing fps 
void SetCaption(char * msg) {
		SDL_SetWindowTitle(screen, msg);
}

// Initialize all setup, set screen mode, load images etc 
void InitSetup() {
	//srand((unsigned int)time(NULL));
	srand(0);
	SDL_Init(SDL_INIT_EVERYTHING);
	SDL_CreateWindowAndRenderer(WIDTH, HEIGHT, SDL_WINDOW_SHOWN, &screen, &renderer);
	if (!screen) {
		LogError("InitSetup failed to create window","");
	}
	SetCaption("Onslaught");
	LoadTextures();
}

// Cleans up after game over 
void FinishOff() {
	SDL_DestroyRenderer(renderer);
	SDL_DestroyWindow(screen);
	//Quit SDL
	SDL_Quit();
	exit(0);
}

// read a character 
char getaChar() {
	int result = -1;

	while (SDL_PollEvent(&event)) {
		if (event.type == SDL_KEYDOWN)
		{
			result = event.key.keysym.sym;
			break;
		}
	}
	return result;
}

// isonmap, check if x and y are in the map, return 1 if so, 0 otherwise 
int isonmap(int x, int y) {
	if (x >= 0 && x < MAPWIDTH && y >= 0 && y < MAPHEIGHT)
		return 1;
	else return 0;
}

// Draws a hex colour 0-8 at x,y with dimensions hx and hy alt is odd row flag
void DrawHex(int c, int atx, int aty, int hx, int hy, int alt) {
	SDL_Rect hex, target;
	int sizex = 32;
	target.h = 34;
	target.w = 32;
	target.x = (Sint16)(atx + (alt * sizex / 2));
	target.y = (Sint16)aty;
	hex.h = 34;
	hex.w = 32;
	hex.x = 0;
	hex.y = 0; 
	//printf("c = %d x=%d y = %d\n",c,target.x,target.y);
	SDL_RenderCopy(renderer, textures[c], &hex, &target);
}

// DrawHexagons - draws all map
void DrawHexagons() {
	int ix, iy, xo, yo, alt, mx, my, lx;
	int hx=0;
	int hy=0;
	Uint8 c, e, u;
	int m;
	char buff[20];
	startTimer(&s);
	int numy = 28;//(HEIGHT / 25) - 2;
	int numx = 31; //(WIDTH / 32) - 8;  was -1 
	alt = 1;
	for (iy = 0; iy < numy; iy++) {
		yo = iy * 25;
		my = hy + iy;
		for (ix = 0; ix < numx; ix++) {
			xo = ix * 32;
			mx = hx + ix;
			if (isonmap(ix, iy)) {
				m = map[ix][iy];
				DrawHex(m, xo, yo, mx, my, alt);
			}
		}
		alt = 1 - alt;  // toggle 1<->0 
	}	
	stopTimer(&s);
	SDL_RenderPresent(renderer);
	snprintf(buff,sizeof(buff),"%10.6f", diff(&s));
	SetCaption(buff);
}

// main game loop. Handles demo mode, high score and game play 
void GameLoop() {
	int gameRunning = 1;
	startTimer(&s);
	while (gameRunning)
	{
		DrawHexagons();
		while (SDL_PollEvent(&event)) {
			switch (event.type) {
				case SDL_KEYDOWN:
					keypressed = event.key.keysym.sym;
					if (keypressed == QUITKEY)
					{
						gameRunning = 0;
						break;
					}
					break;
				case SDL_QUIT:  // if mouse click to close window 
				{
					gameRunning = 0;
					break;
				}
				case SDL_KEYUP: {
					break;
				}
			}  // switch 

		}  // while SDL_PollEvent 
	}
}

// Set Map to random colours
void InitMap(){
	memset(map,0,sizeof(map));
	for (int y=0;y<MAPHEIGHT;y++){
		for (int x=0;x<MAPWIDTH;x++){
			map[x][y]= Random(NUMTEXTURES)-1;
		}
	}
}

// main routine
int main(int argc,char * args[])
{
	InitSetup();
	InitMap();
	GameLoop();
	FinishOff();
    return 0;
}
